<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>ERROR</title>
</head>
<body>
	<h1>ERRRROOOOORRRRRR</h1>
	<?= $this->section('content') ?>
</body>
</html>