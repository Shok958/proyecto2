<?php $this->layout('layout') ?>

<div class="container">
	<h2>Página Privada</h2>
	<p>Sólo deberías ver esta página si estás logueado correctamente</p>
	<p><?= Session::get('user_name') ?></p>
</div>