<p><?= $titulo ?></p>
<div>Esto imita a un banner</div>
<p>Esta variable <?= $dato ?> es propia es esta sección</p>