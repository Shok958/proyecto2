<!-- navigation -->
<div class="navigation">
    <a href="<?php echo URL; ?>">home</a>
    <a href="<?php echo URL; ?>preguntas/todas">Preguntas</a>
    <a href="<?php echo URL; ?>preguntas/crear">Insertar</a>
    <a href="<?php echo URL; ?>privado">Privado</a>
    <a href="<?php echo URL; ?>login">Login</a>
    <a href="<?php echo URL; ?>login/salir">Salir</a>
</div>