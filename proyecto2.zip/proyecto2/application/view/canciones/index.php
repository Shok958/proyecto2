<div class="container">
	Hola!!!
	<p>
		Lorem ipsum dolor sit amet, 
		consectetur adipisicing elit. 
		Culpa nostrum tempore enim doloribus 
		repudiandae soluta, eveniet voluptatum. 
		Voluptas perferendis ea recusandae porro 
		assumenda incidunt numquam magni laborum sed, 
		quo ipsum?
	</p>
	<?= APP ?>
</div>