<div class="container">
    <h2>Estás en la Vista: application/view/home/index.php (everything in the box comes from this file)</h2>
    <p>En una aplicación real esta sería la página de Inicio.</p>
    <h3>HOLA MUNDO!!!</h3>
</div>
