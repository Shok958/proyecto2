<div class="container">
	<h2>Gracias por preguntar!</h2>
	<p>
		Vivimos de preguntas y respuestas!. Todo empieza aquí, enhorabuena por comenzar el giro de esta rueda...
	</p>
	<p>
		Ahora practica con el ejemplo y contesta a alguna de las preguntas que otros compañeros han formulado
	</p>
	<p>
		<a href="/preguntas/todas">Volver</a>
	</p>
</div>